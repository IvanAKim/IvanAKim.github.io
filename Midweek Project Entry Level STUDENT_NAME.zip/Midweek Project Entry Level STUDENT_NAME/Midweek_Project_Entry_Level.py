#Students Names:

#1
#For each of the following variables assign a type of your
#choice to each based on their variable name. I have done
#the first one for you.

#Problem 1 Part A
int_variable = 5

#Problem 1 Part B
float_variable = _

#Problem 1 Part C
bool_variable = _

#Problem 1 Part D
str_variable = _

#Problem 1 Part E
list_variable = _

#DO NOT CHANGE ASSERT STATEMENTS
assert type(int_variable) == int, "Variable int is not of int type"
print("Problem 1 Part A: Correct")

assert type(float_variable) == float, "Variable float is not of float type"
print("Problem 1 Part B: Correct")

assert type(bool_variable) == bool, "Variable bool is not of bool type"
print("Problem 1 Part C: Correct")

assert type(str_variable) == str, "Variable str is not of str type"
print("Problem 1 Part D: Correct")

assert type(list_variable) == list, "Variable list is not of list type"
print("Problem 1 Part E: Correct")













#2
#Convert the following int_variable to a str and the following
#str_variable to an int

int_variable = 5
str_variable = "5"

#Problem 2 Part A
int_variable = _

#Problem 2 Part B
str_variable = _

#DO NOT CHANGE ASSERT STATEMENTS
assert type(int_variable) == str, "variable int is not of type str"
print("Problem 2 Part A: Correct")
assert type(str_variable) == int, "variable int is not of type str"
print("Problem 2 Part B: Correct")








#3
#You have a variable named ages and its an empty list.
#append your age to the list
#You also have a variable called your_age.
#Make your_age equal to the age you appended.
#NOTE: If you are doing paired programming, just do 1 of you ages.
ages = []

#Delete this and append here

your_age = _

#DO NOT CHANGE ASSERT STATEMENTS
assert ages[0] == your_age, "The ages do not match"
print("Problem 3: Correct")












#4
#You have a variable letters and its equal to 4 characters
#You also have four variables representing a letter.
#You need to spell the word bear by indexing the letters list.
#I have done the first one for you.
letters = ["a", "b", "r", "e"]

first_letter = letters[1]
second_letter = letters[_]
third_letter = letters[_]
fourth_letter = letters[_]


#DO NOT CHANGE ASSERT STATEMENTS
assert "".join([first_letter, second_letter, third_letter, fourth_letter]) == "bear", "Does not equal bear!"
print("Problem 4: Correct")











#5
#You have a variable named temp that is equal to 0.
#What would temp be after the while loop is run.
#Put your answer in the variable called answer.
temp = 0
answer = _

count = 3
while count != 0:
    temp += 1
    count -= 1


#DO NOT CHANGE ASSERT STATEMENTS
assert temp == answer, "temp and answer are not the same"
print("Problem 5: Correct")










#6
#You have an empty dictionary named phonebook
#You also have two variables called key and value.
#Add both variables to the dictionary where the variable
#key is the key and the variable value is the value
phonebook = dict()

key = "key"
value = "value"

#Delete this and write here.


#DO NOT CHANGE ASSERT STATEMENTS
assert [phonebook[i] for i in phonebook][0] == "value", "You didn't add correctly"
print("Problem 6: Correct")








#7
#You have an empty set called characters
#Strings are added to the set.
#How many things are in the set.
#Write your answer in the variable called answer.
characters = set()

characters.add("Mario")
characters.add("Luigi")
characters.add("Peach")
characters.add("Luigi")

answer = _



#DO NOT CHANGE ASSERT STATEMENTS
assert len(characters) == answer, "Not equal"
print("Problem 7: Correct")








#8
#Based on the following for loop, what would the value of temp be
#after the for loop is finished?
#Write your answer in the variable called answer.
temp = 0
answer = _
for i in range(0, 6, 1):
    temp = i


#DO NOT CHANGE ASSERT STATEMENTS
assert temp == answer, "Not Equal"
print("Problem 8: Correct")









#9
#Baseed on this funciton what would it return.
#put your answer in the variable called answer.
def function(value:int) -> bool:
    if value % 2 == 0:
        return True
    else:
        return False
    
temp = function(5)
answer = _


#DO NOT CHANGE ASSERT STATEMENTS
assert temp == answer, "Not equal"
print("Problem 9: Correct")










#10
#Fill in the blanks of the following function
#The function given a list of ints, adds them all up
def SumValues(values:list) -> int:
    '''Given a list adds all ints together'''
    sum = 0
    for i in values:
        _ += _
    return _


#DO NOT CHANGE ASSERT STATEMENTS
result = SumValues([1,2,3,4,5])
assert result == 15, "Not Equal"
print("Problem 10: Correct")










#11
#Given a text file called test.txt
#I want you to delete everything in the textfile,
#then write "Hello".
file = open("test.txt", _)
#Delete here and write to the file.
file.close()

#DO NOT CHANGE ASSERT STATEMENTS
with open("test.txt", "r") as test:
    assert test.readline() == "Hello", "Not Equal"
    print("Problem 11: Correct")









#12
#Fill in the following blanks for the class counter
class Counter:
    def __init__(self):
        self.counter = 0
        
    def AddToCounter(self) -> None:
        _ += 1
        
    def ResetCounter(self) -> None:
        _ = 0

    def GetCounter(self) -> int:
        return _

#DO NOT CHANGE ASSERT STATEMENTS
c = Counter()
c.AddToCounter()
c.AddToCounter()
c.AddToCounter()
assert c.GetCounter() == 3, "Add To Counter Not Working or Get Counter"
c.ResetCounter()
assert c.GetCounter() == 0, "Reset Counter Not Working"
print("Problem 12: Correct")



    

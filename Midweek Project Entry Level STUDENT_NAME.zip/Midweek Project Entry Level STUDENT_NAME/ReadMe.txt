Instructions:
1. Rename the folder by replacing the STUDENT_NAME with your name. Right-Click the folder and select rename to do so.
2. For all python scripts please add your name to where the comment tells you. 
3. Read each problem carefully.
4. Do not change the assert statements.
NOTE: I WILL NOT BE GRADING BASED OFF THE ASSERT STATEMENTS, THEY ARE THERE FOR YOU TO KNOW IF YOU GOT IT RIGHT OR WRONG.
5. You will have 2 weeks to complete this assignemnt, you will have all of class time for weeks 9 and 10. 
6. You are allowed to work in groups of 2 with paired progamming, just be sure to put both your names on the script. 
7. Note: Paired programming means that two people use the same computer and edit the same files.  
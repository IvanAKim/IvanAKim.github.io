##Student Name: 


import time
import random
class TicTacToe:
    def __init__(self, hasAi=False):
        self.board = [[9,8,7], [6,5,4], [3,2,1]]
        self.isPlayer1 = True
        self.gameover = False
        self.hasAi = hasAi

    def Display_Board(self):
        print('   |   |')
        print(' ' + str(self.board[0][0]) + ' | ' + str(self.board[0][1]) + ' | ' + str(self.board[0][2]))
        print('   |   |')
        print('-----------')
        print('   |   |')
        print(' ' + str(self.board[1][0]) + ' | ' + str(self.board[1][1]) + ' | ' + str(self.board[1][2]))
        print('   |   |')
        print('-----------')
        print('   |   |')
        print(' ' + str(self.board[2][0]) + ' | ' + str(self.board[2][1]) + ' | ' + str(self.board[2][2]))
        print('   |   |')


    def  Add_Value(self, value):
        try:
            num = int(value)
            for i in range(len(self.board)):
                for j in range(len(self.board[i])):
                    if num == self.board[i][j]:
                        if self.isPlayer1:
                            self.board[i][j] = "X"
                            self.Switch_Player()
                            self.Check_Winner("X")
                            return
                            
                        else:
                            self.board[i][j] = "O"
                            self.Switch_Player()
                            self.Check_Winner("O")
                            return
            print("That is not a valid input\n")
                            

        except ValueError:
            print("That is not a valid input\n")


    def Switch_Player(self):
        if self.isPlayer1:
            self.isPlayer1 = False
        else:
            self.isPlayer1 = True

    def Get_Player(self):
        if self.isPlayer1:
            return "Player 1"
        else:
            if self.hasAi:
                return "Ai Turn"
            else:
                return "Player 2"

    def Check_Winner(self, mark):
        if self.Check_Horizontal_Wins(mark) or self.Check_Vertical_Wins(mark) or self.Check_Diagonal(mark):
            if mark == "X":
                self.Display_Board()
                print("Player 1 has won!")
                self.gameover = True
            elif mark == "O":
                self.Display_Board()
                if self.hasAi:
                    print("Ai has won!")
                else:
                    print("Player 2 has won!")
                self.gameover = True
        elif self.Check_Draw():
            self.Display_Board()
            print("Its a tie!")
            self.gameover = True
        

    def Check_Horizontal_Wins(self, mark):
        return (self.board[0][0] == mark and self.board[0][1] == mark and self.board[0][2] == mark) or\
               (self.board[1][0] == mark and self.board[1][1] == mark and self.board[1][2] == mark) or\
               (self.board[2][0] == mark and self.board[2][1] == mark and self.board[2][2] == mark)

    ##Fill in for Vertical Win Condition
    def Check_Vertical_Wins(self, mark):
        pass

    ##Fill in for Diagonal Win Condition
    def Check_Diagonal(self, mark):
        pass

    ##Fill in for Draw Condition
    def Check_Draw(self):
        pass
            
    ##Reset self.board, self.isPlayer1, self.gameover to their defaults.
    ##Hint: Look at __init__
    def Reset(self):
        pass

    ##Only work on this if you finished the project early.
    def AiMove(self):
        pass

def StartGameNoAi() -> None:
    c = TicTacToe()
    running = True
    while running:
        if c.gameover:
            option = input("Would you like to play again?(Y or N)\n")
            if option.upper() == "Y":
                c.Reset()
            elif option.upper() == "N":
                running = False
            else:
                print("That is not a valid input")
        else:
            c.Display_Board()
            option = input(f"{c.Get_Player()} it is your turn\n")
            c.Add_Value(option)

def StartGameWithAi():
    c = TicTacToe(True)
    running = True
    while running:
        if c.gameover:
            option = input("Would you like to play again?(Y or N)\n")
            if option.upper() == "Y":
                c.Reset()
            elif option.upper() == "N":
                running = False
            else:
                print("That is not a valid input")
        else:
            c.Display_Board()
            if c.Get_Player() == "Ai Turn":
                print(f"{c.Get_Player()} it is your turn\n")
                print("Ok I'm thinking...")
                time.sleep(3)
                print("Ok I got it")
                c.AiMove()
                
            else:
                option = input(f"{c.Get_Player()} it is your turn\n")
                c.Add_Value(option)
 
if __name__ == "__main__":
    StartGameNoAi()
    ##StartGameWithAi()

        
        
